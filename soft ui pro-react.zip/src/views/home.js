import React from 'react'

import { Helmet } from 'react-helmet'

import Header from '../components/header'
import PrimaryPinkButton from '../components/primary-pink-button'
import OutlineGrayButton from '../components/outline-gray-button'
import OutlineBlackButton from '../components/outline-black-button'
import ListItem from '../components/list-item'
import Footer from '../components/footer'
import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Soft UI Pro</title>
        <meta property="og:title" content="Soft UI Pro" />
      </Helmet>
      <Header></Header>
      <div className="home-hero">
        <div className="home-container01">
          <div className="home-card">
            <h1 className="home-text">We make tech small</h1>
            <h1 className="home-text01">
              And affordable so it is available to all
            </h1>
            <span className="home-text02">
              Find about out our projects and help us grow
            </span>
            <div className="home-container02">
              <div className="home-container03">
                <PrimaryPinkButton button="contact us"></PrimaryPinkButton>
              </div>
              <OutlineGrayButton button="read more"></OutlineGrayButton>
            </div>
            <div className="home-container04">
              <img alt="image" src="/1-1500h.png" className="home-image" />
              <span className="home-text03">Nano_Process_on</span>
            </div>
          </div>
        </div>
      </div>
      <img alt="image" src="/curved6-900h.jpg" className="home-image01" />
      <section className="home-container05">
        <div className="home-container06">
          <h1 className="home-text04">Nano_Process_On</h1>
          <span className="home-text05">
            The power of  portability to make pc inside a pendrive 
          </span>
        </div>
        <div className="home-container07">
          <div className="home-container08">
            <img
              alt="image"
              src="/original-xiaomi-usb-32-flash-drive-64gb-128gb-pen-drive-type-c-usb-stick-pen-drive-flash-usb-disk-type-c-flash-drive-xiaomi-128-gb-918901-1100w.jpg"
              className="home-image02"
            />
            <div className="home-container09">
              <img
                alt="image"
                src="https://raw.githubusercontent.com/creativetimofficial/public-assets/master/soft-ui-design-system/assets/img/coding.jpg"
                className="home-image03"
              />
            </div>
          </div>
          <div className="home-container10">
            <div className="home-container11">
              <h3 className="home-text06">So What Is nano_process_on</h3>
              <p className="home-text07">
                <span>
                  Imagine if you could carry a PC in your pocket and use it
                  anywhere you want Sounds impossible right Well not anymore
                  With our project, you can turn any pen drive into a fully
                  functional PC that can run any operating system and any
                  software Many people in the world face challenges such as lack
                  of access affordability or convenience when it comes to using
                  a PC for their work education or entertainment According to
                  the World Bank only 54% of the global population has access to
                  the internet and only 45% has access to a computer That means
                  millions of people are missing out on opportunities and
                  resources that could improve their lives First let me explain
                  how our project works our project uses virtualization
                  technology to emulate all the components of a PC on a pen
                  drive This means that the pen drive acts as the main hard disk
                  of the PC and stores all the files and programs The pen drive
                  can then be plugged into any device that has a USB port and a
                  screen such as a TV or a smartphone The device will then
                  recognize the pen drive as a PC and allow you to boot up any
                  operating system and run any software on it It is affordable
                  as our project costs only 10% of the price of a normal PC You
                  only need to buy one pen drive and one software license for
                  each operating system you want to use You don&apos;t need to
                  buy any other hardware or accessories It is accessible as our
                  project can be used anywhere there is a USB port and a screen
                  You don&apos;t need to worry about finding an outlet or
                  carrying around bulky equipment You can also share your pen
                  drive with others who need to use a PC
                </span>
                <br></br>
                <br></br>
              </p>
            </div>
          </div>
        </div>
      </section>
      <section className="home-testimonials">
        <div className="home-container12">
          <div className="home-container13">
            <div className="home-container14">
              <h2 className="home-text11">
                Our project will help every sector
              </h2>
              <p className="home-text12 Lead">Whatever the work is</p>
              <p className="home-text13 Body">
                <span className="home-text14">
                  &quot;Take up one idea. Make that one idea your life - think
                  of it, dream of it, live on that idea. Let the brain, muscles,
                  nerves, every part of your body, be full of that idea, and
                  just leave every other idea alone. This is the way to success.
                  A single rose can be my garden... a single friend, my
                  world.&quot;
                </span>
              </p>
              <p className="home-text15">Tanuj Sharma</p>
              <p className="home-text16 Small">Project manager, Founder</p>
              <div className="home-container15"></div>
            </div>
          </div>
          <div className="home-logos">
            <div className="home-container16">
              <div className="home-container17">
                <div className="home-container18">
                  <img
                    alt="image"
                    src="/logo-asana.svg"
                    className="home-image04"
                  />
                </div>
                <div className="home-container19">
                  <img
                    alt="image"
                    src="/logo-slack.svg"
                    className="home-image05"
                  />
                </div>
                <div className="home-container20">
                  <a
                    href="https://drive.google.com/"
                    target="_blank"
                    rel="noreferrer noopener"
                  >
                    <img
                      alt="image"
                      src="/logo-google-drive.svg"
                      className="home-image06"
                    />
                  </a>
                </div>
              </div>
              <div className="home-container21">
                <div className="home-container22">
                  <a
                    href="https://www.shopify.com/"
                    target="_blank"
                    rel="noreferrer noopener"
                  >
                    <img
                      alt="image"
                      src="/logo-shopify.svg"
                      className="home-image07"
                    />
                  </a>
                </div>
                <div className="home-container23">
                  <a
                    href="https://www.apple.com/"
                    target="_blank"
                    rel="noreferrer noopener"
                  >
                    <img
                      alt="image"
                      src="https://demos.creative-tim.com/soft-ui-design-system-pro/assets/img/logos/small-logos/logo-apple.svg"
                      className="home-image08"
                    />
                  </a>
                </div>
                <div className="home-container24">
                  <a
                    href="https://www.invisionapp.com/"
                    target="_blank"
                    rel="noreferrer noopener"
                  >
                    <img
                      alt="image"
                      src="/logo-invision.svg"
                      className="home-image09"
                    />
                  </a>
                </div>
              </div>
              <div className="home-container25">
                <div className="home-container26">
                  <img
                    alt="image"
                    src="/logo-attlasian.svg"
                    className="home-image10"
                  />
                </div>
                <div className="home-container27">
                  <img
                    alt="image"
                    src="/logo-weave.svg"
                    className="home-image11"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <img alt="image" src="/bottom.svg" className="home-bottom-wave-image" />
        <img alt="image" src="/waves-white.svg" className="home-image12" />
        <img alt="image" src="/top.svg" className="home-top-wave-image" />
      </section>
      <section className="home-contaier">
        <div className="home-container28">
          <div className="home-container29">
            <svg viewBox="0 0 1024 1024" className="home-icon">
              <path d="M363.722 722.052l41.298-57.816-45.254-45.256-57.818 41.296c-10.722-5.994-22.204-10.774-34.266-14.192l-11.682-70.084h-64l-11.68 70.086c-12.062 3.418-23.544 8.198-34.266 14.192l-57.818-41.298-45.256 45.256 41.298 57.816c-5.994 10.72-10.774 22.206-14.192 34.266l-70.086 11.682v64l70.086 11.682c3.418 12.060 8.198 23.544 14.192 34.266l-41.298 57.816 45.254 45.256 57.818-41.296c10.722 5.994 22.204 10.774 34.266 14.192l11.682 70.084h64l11.68-70.086c12.062-3.418 23.544-8.198 34.266-14.192l57.818 41.296 45.254-45.256-41.298-57.816c5.994-10.72 10.774-22.206 14.192-34.266l70.088-11.68v-64l-70.086-11.682c-3.418-12.060-8.198-23.544-14.192-34.266zM224 864c-35.348 0-64-28.654-64-64s28.652-64 64-64 64 28.654 64 64-28.652 64-64 64zM1024 384v-64l-67.382-12.25c-1.242-8.046-2.832-15.978-4.724-23.79l57.558-37.1-24.492-59.128-66.944 14.468c-4.214-6.91-8.726-13.62-13.492-20.13l39.006-56.342-45.256-45.254-56.342 39.006c-6.512-4.766-13.22-9.276-20.13-13.494l14.468-66.944-59.128-24.494-37.1 57.558c-7.812-1.892-15.744-3.482-23.79-4.724l-12.252-67.382h-64l-12.252 67.382c-8.046 1.242-15.976 2.832-23.79 4.724l-37.098-57.558-59.128 24.492 14.468 66.944c-6.91 4.216-13.62 8.728-20.13 13.494l-56.342-39.006-45.254 45.254 39.006 56.342c-4.766 6.51-9.278 13.22-13.494 20.13l-66.944-14.468-24.492 59.128 57.558 37.1c-1.892 7.812-3.482 15.742-4.724 23.79l-67.384 12.252v64l67.382 12.25c1.242 8.046 2.832 15.978 4.724 23.79l-57.558 37.1 24.492 59.128 66.944-14.468c4.216 6.91 8.728 13.618 13.494 20.13l-39.006 56.342 45.254 45.256 56.342-39.006c6.51 4.766 13.22 9.276 20.13 13.492l-14.468 66.944 59.128 24.492 37.102-57.558c7.81 1.892 15.742 3.482 23.788 4.724l12.252 67.384h64l12.252-67.382c8.044-1.242 15.976-2.832 23.79-4.724l37.1 57.558 59.128-24.492-14.468-66.944c6.91-4.216 13.62-8.726 20.13-13.492l56.342 39.006 45.256-45.256-39.006-56.342c4.766-6.512 9.276-13.22 13.492-20.13l66.944 14.468 24.492-59.13-57.558-37.1c1.892-7.812 3.482-15.742 4.724-23.79l67.382-12.25zM672 491.2c-76.878 0-139.2-62.322-139.2-139.2s62.32-139.2 139.2-139.2 139.2 62.322 139.2 139.2c0 76.878-62.32 139.2-139.2 139.2z"></path>
            </svg>
          </div>
          <h1 className="home-text17">Specification of Nano_Process_on </h1>
          <h3 className="home-text18 HeadingTwo">
            <span>Know your #powerofportablity</span>
            <br></br>
          </h3>
        </div>
        <div className="home-container30">
          <div className="home-container31">
            <div className="home-container32"></div>
            <div className="home-container33">
              <svg viewBox="0 0 987.4285714285713 1024" className="home-icon2">
                <path d="M438.857 508.571l312 312c-79.429 80.571-190.286 130.286-312 130.286-242.286 0-438.857-196.571-438.857-438.857s196.571-438.857 438.857-438.857v435.429zM545.714 512h441.714c0 121.714-49.714 232.571-130.286 312zM950.857 438.857h-438.857v-438.857c242.286 0 438.857 196.571 438.857 438.857z"></path>
              </svg>
              <h1 className="home-text21">Watch the release Teaser</h1>
              <span className="home-text22">Nano_process_on</span>
              <OutlineBlackButton button="Play Video"></OutlineBlackButton>
            </div>
          </div>
          <div className="home-container34">
            <ListItem></ListItem>
          </div>
        </div>
        <div className="home-divider"></div>
      </section>
      <Footer></Footer>
    </div>
  )
}

export default Home
