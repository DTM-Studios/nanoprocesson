import React from 'react'

import { Helmet } from 'react-helmet'

import './not-found.css'

const NotFound1 = (props) => {
  return (
    <div className="not-found1-container">
      <Helmet>
        <title>Not-Found - Soft UI Pro</title>
        <meta property="og:title" content="Not-Found - Soft UI Pro" />
      </Helmet>
      <h1>404 NOT FOUND</h1>
      <span>Sorry for inconvience</span>
    </div>
  )
}

export default NotFound1
