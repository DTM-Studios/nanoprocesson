import React from 'react'

import PropTypes from 'prop-types'

import './list-item.css'

const ListItem = (props) => {
  return (
    <div className="list-item-container">
      <span>{props.description}</span>
    </div>
  )
}

ListItem.defaultProps = {
  description:
    'NanoProcessOn is so small that you can take it anywhere and use it anytime. just conect it to any display and boom you have a pc',
  newProp: '1. Listen to Social Conversations',
}

ListItem.propTypes = {
  description: PropTypes.string,
  newProp: PropTypes.string,
}

export default ListItem
